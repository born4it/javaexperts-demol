package javaexperts.demol.dao;

public class AntwoordDao extends Dao {
}
