package javaexperts.demol.dao;

public class VraagDao extends Dao {
}

