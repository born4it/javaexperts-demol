package javaexperts.demol.dao;

public class AfleveringDao extends Dao {
}
