package javaexperts.demol.dao;

import java.util.List;

public class AfleveringDao extends Dao {
}
