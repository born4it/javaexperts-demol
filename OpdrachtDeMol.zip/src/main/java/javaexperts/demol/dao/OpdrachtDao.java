package javaexperts.demol.dao;

public class OpdrachtDao extends Dao {
}
