package javaexperts.demol.dao;

public class KandidaatDao extends Dao {
}
