package javaexperts.demol;

public interface Geavanceerd {
}
