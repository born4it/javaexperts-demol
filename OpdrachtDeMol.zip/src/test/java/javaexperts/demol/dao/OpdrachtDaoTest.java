package javaexperts.demol.dao;

import javaexperts.demol.Geavanceerd;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.Optional;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.*;

public class OpdrachtDaoTest {

    private OpdrachtDao opdrachtDao = new OpdrachtDao();

    @Test
    @Category(Geavanceerd.class)
    public void findPlaatsMetMeesteOpdrachten() {
        Optional<Plaats> plaatsMetMeesteOpdrachten = opdrachtDao.findPlaatsMetMeesteOpdrachten();

        if (plaatsMetMeesteOpdrachten.isPresent()) {
            assertThat("findPlaatsMetMeesteOpdrachten: verschil met verwachte plaats"
                    , plaatsMetMeesteOpdrachten.get(), equalTo(Plaats.KAAPSTAD));

        } else {
            fail("findPlaatsMetMeesteOpdrachten: plaats niet teruggeven!");
        }
    }

}